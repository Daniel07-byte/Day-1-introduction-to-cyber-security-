# Day 1: Introduction to Cybersecurity

# Description :

> This chapter introduces the basics of cybersecurity, including its core purpose, foundational principles (CIA Triad), and key concepts like threats, risks, and vulnerabilities.
> 

**📅 Date:** July 28, 2025

---

## 🔐 What is Cybersecurity?

Cybersecurity is the practice of protecting systems, networks, and data from cyber attacks. It includes preventing unauthorized access, data breaches, and maintaining the security of digital assets.

---

## 🎯 The CIA Triad

The **CIA Triad** is the foundation of cybersecurity:

- **Confidentiality**: Only authorized users can access the data.
- **Integrity**: Data remains accurate and unchanged.
- **Availability**: Systems and data are available when needed.

---

## 🧠 Key Concepts

| Term | Meaning |
| --- | --- |
| Asset | Something valuable like data or devices |
| Threat | Potential danger to an asset |
| Vulnerability | Weakness that can be exploited |
| Risk | Likelihood of a threat exploiting a vulnerability |

---

## 👤 Roles in Cybersecurity

- **Security Analyst**: Monitors systems for threats
- **Penetration Tester**: Finds security weaknesses
- **Incident Responder**: Handles breaches
- **Security Architect**: Designs secure systems

---

## ✍️ Summary

Today I learned the core foundation of cybersecurity, including the **CIA Triad**, key concepts like assets and threats, and various job roles in the field.